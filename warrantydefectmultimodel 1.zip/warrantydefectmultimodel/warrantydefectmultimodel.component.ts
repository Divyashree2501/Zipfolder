import { Component, Inject, Input, ViewChild } from '@angular/core';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MomentDateAdapter } from '@angular/material-moment-adapter';
import * as _moment from 'moment';
import { Moment } from 'moment';
import { MatDatepicker } from '@angular/material/datepicker';
import { FormControl, FormGroup } from '@angular/forms';
import * as moment from 'moment';
import * as Highcharts from 'highcharts';
import HC_more from 'highcharts/highcharts-more';
import HighchartsExporting from 'highcharts/modules/exporting';
import { MatTabChangeEvent } from '@angular/material/tabs';
import { EyeqService } from '../eyeq.service';
import { Router } from '@angular/router';
import { MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import { NgxSpinnerService } from 'ngx-spinner';
import { HttpResponse } from '@angular/common/http';
import swal from 'sweetalert2';
import { WarrantymultimodelpopupComponent } from '../warrantymultimodelpopup/warrantymultimodelpopup.component';
import { DialogData } from '../createnotice/createnotice.component';

interface ChartData {
  modelType: string;
  chartOptions: Highcharts.Options;
}

export const MY_FORMATS = {
  parse: {
    dateInput: 'MM/YYYY',
  },
  display: {
    dateInput: 'MM/YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

export const MY_FORMATS1 = {
  display: {
    dateInput: 'MMM YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};


@Component({
  selector: 'app-warrantydefectmultimodel',
  templateUrl: './warrantydefectmultimodel.component.html',
  styleUrls: ['./warrantydefectmultimodel.component.css'],
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS1 },
  ]
})
export class WarrantydefectmultimodelComponent {
  selectedsens: any;
  selectedsens1: any;
  showchart: any = false;
  showdata: any = false;
  showTrendView: any = false;
  showBarView: any = false;

  viewtrendbtn: any = true;

  standardmast: any = [];
  Gradenamedetails: any = [];
  selectedTimePeriodType = '1';

  finalarr: any = []
  financialToggle: boolean = false;
  hiddde: boolean = false;
  custom: boolean = false;

  financialYears: string[] = [];
  selectedYear: string = ''; // Holds the selected year
  selectedYear1: string = ''; // Replace with your actual date range
  beforeHyphen: string | undefined;
  afterHyphen: string | undefined;

  // data: { item_id: number; item_text: string; }[] = [];
  drpserver: any = [];
  drpserversetting = {};
  partselected: any = [];

  drppartserver: any = [];
  drppartserversetting = {};
  materialselected: any = [];

  drpVariantserver: any = [];
  drpVariantserversetting = {};
  Variantselected: any = [];

  start: any = [];
  end: any = [];
  date = new FormControl(new Date());
  tomorrow = new Date();

  fdate = new FormControl(moment());
  tdate = new FormControl(moment());

  selectedPlant: string;
  plants = [
    { value: '1', viewValue: 'HOS' },
    { value: '2', viewValue: 'MYSR' },
    { value: '3', viewValue: 'HP' },
    { value: '4', viewValue: 'H001' },
    { value: '5', viewValue: 'Test' }
  ];

  dropdownSettingPlant = {};
  plantsList: any = [];
  selectedPlantsList: any[] = [];

  FDateString: any;
  TDateString: any;
  PartString: string;
  PlantString: string;
  ModelVarientString: string;
  rslt: any = [];

  //-- Start of Incl. by Divya
  @Input() name: any;
  rslt1: any = [];
  TrendArray: any = [];
  public Model_Varient: any = [];
  public ThreeMonthData: any = [];
  public SixMonthData: any = [];
  public TewlveMonthData: any = [];

  threemonthseriesValuedata: any;
  sixmonthseriesValuedata: any;
  twelvemonthseriesValuedata: any;
  //-- End of Incl. by Divya

  // public Model_Varient: any = [];
  public Month: any = [];
  public OneMonthDefData: any = [];
  public ThreeMonthDefData: any = [];
  public SixMonthDefData: any = [];
  public NineMonthDefData: any = [];
  public TewlveMonthDefData: any = [];

  OnemonthseriesValuedata: any;
  ThreemonthseriesValuedata: any;
  SixmonthseriesValuedata: any;
  NinemonthseriesValuedata: any;
  TwelvemonthseriesValuedata: any;

  Highcharts: any = Highcharts;
  chartDataArray: ChartData[] = [];
  uniqueModelVariant: any = [];
  TrenddataSeries: any[] = [];
  selectedPartList: any[] = [];
  selectedModelVarientList: any[] = [];

  constructor(private renav: Router, private dialog: MatDialog, private Api_Service: EyeqService, private spinner: NgxSpinnerService, @Inject(MAT_DIALOG_DATA) public data: DialogData) {
  }
  profileForm = new FormGroup({
    // Plant: new FormControl(''),
    // MATNR: new FormControl(''),
    // PartDesc: new FormControl(''),
    // Supplier: new FormControl(''),
    // datefrom: new FormControl(''),
    // dateto: new FormControl(''),
    // item_text: new FormControl(''),
    // PartNo: new FormControl('')
  });

  onPlantSelection(event: any) {
    console.log('Selected plant: ' + this.selectedPlant);
  }

  generateFinancialYears() {
    const currentYear = new Date().getFullYear();
    for (let i = 0; i < 2; i++) {
      const startYear = currentYear - i;
      this.financialYears.push(`${startYear} - ${startYear + 1}`);
    }
    this.financialYears.reverse(); // Reverse the array to show the latest year first
  }

  selectCurrentFinancialYear() {
    const currentDate = new Date();
    const currentYear = currentDate.getFullYear();
    this.selectedYear = `${currentYear} - ${currentYear + 1}`;
    this.selectedYear1 = this.selectedYear;
    console.log('Selected Financial Year:', this.selectedYear1);
    const parts = this.selectedYear1.split('-');
    if (parts.length === 2) {
      this.beforeHyphen = parts[0];
      console.log('hyphen before parts length', this.beforeHyphen);
      this.afterHyphen = parts[1];
      console.log('hyphen  after parts length', this.afterHyphen);
    }
  }

  onSelectedYearChange(newValue: string) {
    this.selectedYear1 = newValue;
    console.log('Selected Financial Year:', this.selectedYear1);
    const parts = this.selectedYear1.split('-');
    if (parts.length === 2) {
      this.beforeHyphen = parts[0];
      console.log('hyphen before parts length', this.beforeHyphen);
      this.afterHyphen = parts[1];
      console.log('hyphen  after parts length', this.afterHyphen);
    }

    // if (this.type2 == 'quaterly') {
    //   this.chartbinding(this.type2);
    // } else if (this.type2 == 'monthlydata') {
    //   this.chartbinding(this.type2);
    // } else {
    //   this.chartbinding(this.type2);
    // }

    // const yearRange = this.selectedYear1.split('-').map(item => parseInt(item.trim())); if (yearRange.length === 2) { this.selectedYear1 = yearRange[0]; }
  }

  onTimePeriodTypeChange() {
    debugger
    console.log('Selected Time Period Type:', this.selectedTimePeriodType);
    if (this.selectedTimePeriodType === '1') {
      // this.hiddde = true;
      // this.financialToggle = true;
      // this.custom = false;
      this.viewtrendbtn = true;
      this.showTrendView = true;
      this.showBarView = false;
      //this.getTrendViewData();
    } else if (this.selectedTimePeriodType === '2') {

      // this.custom = true;
      // this.hiddde = false;
      // this.financialToggle = false;
      this.viewtrendbtn = true;
      this.showTrendView = false;
      this.showBarView = true;
      // this.getdata();
    }

    // Perform any other actions you want based on the selection change
  }

  onsenselection() {
    const array = this.selectedsens1;
    const quotedCommaSeparatedString1 = array.join(', ');
    const inputString = quotedCommaSeparatedString1;
    const array1 = inputString.split(', ');
    console.log('arrayaaaaaaaaaaaa11', array1);
    const quotedArray = array1.map((item: any) => `'${item}'`);
    // this.value1 = quotedArray.join(', ');
    console.log('slection change', this.selectedsens1)
    if (this.selectedsens1 == '') {
      this.showdata = false
      alert("Please Select")
    }
    else {
      this.showdata = true;
    }

  }

  setFromMonthAndYear(normalizedMonthAndYear: Moment, datepicker: MatDatepicker<Moment>) {
    const ctrlValue = this.fdate.value!;
    ctrlValue.month(normalizedMonthAndYear.month());
    ctrlValue.year(normalizedMonthAndYear.year());
    this.fdate.setValue(ctrlValue);
    datepicker.close();
  }

  setToMonthAndYear(normalizedMonthAndYear: Moment, datepicker: MatDatepicker<Moment>) {
    const ctrlValue = this.tdate.value!;
    ctrlValue.month(normalizedMonthAndYear.month());
    ctrlValue.year(normalizedMonthAndYear.year());
    this.tdate.setValue(ctrlValue);
    datepicker.close();
  }

  setMonthAndYear(normalizedMonthAndYear: Moment, datepicker: MatDatepicker<Moment>) {
    const ctrlValue = this.fdate.value!;
    ctrlValue.month(normalizedMonthAndYear.month());
    ctrlValue.year(normalizedMonthAndYear.year());
    this.fdate.setValue(ctrlValue);
    datepicker.close();
  }

  ngOnInit(): void {
    this.plantsList = [
      { plantCode: 'HOS', plantName: 'HOS' },
      { plantCode: 'MYSR', plantName: 'MYSR' },
      { plantCode: 'HP', plantName: 'HP' },
      { plantCode: 'H001', plantName: '3W' },
      { plantCode: '1001', plantName: '1001' }
    ];

    this.dropdownSettingPlant = {
      singleSelection: false,
      idField: 'plantCode',
      textField: 'plantName',
      allowSearchFilter: false,
      itemsShowLimit: 1,
    };

    // this.showchart = true;
    this.showdata = true;
    // this.viewtrendbtn = true;

    this.GetPartMaster();
    this.GetVariantMaster();
    // this.getdata();
    // this.getTrendViewData();
    // this.Testingmultichart();

    // this.GetParts();
    // this.generateFinancialYears();
    // this.selectCurrentFinancialYear();  
  }

  GetPartMaster() {
    try {
      this.spinner.show()
      // this.splitvcode = this.Vcode.toString().split('-')
      // this.Vcodedis = this.splitvcode[0]
      this.FDateString = this.fdate.value!.format('YYYYMM');
      this.TDateString = this.fdate.value!.format('YYYYMM');
      console.log('date', this.FDateString + ',' + this.TDateString)
      let option = {
        FDATE: this.FDateString,
        TDATE: this.TDateString
      }
      this.Api_Service.GetPartMaster(option).subscribe(
        (data: HttpResponse<any>) => {
          if (data.status == 200) {
            console.log('databricks data', data)
            this.rslt = data.body  //this.PeriodicElement //data.body
            //this.dataSource = new MatTableDataSource(this.rslt) 
            console.log('databricks data length', this.rslt.length)
            // debugger;
            if (this.rslt.length > 0) {
              this.drppartserver = data.body; //this.rslt.toString()
              console.log('this.drpserver', this.drpserver)
            }
            else {
              swal.fire('No records found', '', 'info')
            }
            this.spinner.hide()
            // console.log('databricks data',  this.rslt)
          }
          else {
            this.spinner.hide()
            swal.fire('Validation Error', '', 'error')
          }
          this.spinner.hide()
        },
        (error) => {
          // console.log('error : ', error)
          this.spinner.hide()
          swal.fire(error.error.message, '', 'error')
        }
      )
      this.drppartserversetting = {
        singleSelection: false,
        idField: 'PartNo',
        textField: 'PartDesc',
        selectAllText: 'Select All',
        unSelectAllText: 'UnSelect All',
        itemsShowLimit: 1,
        allowSearchFilter: true
      };
    }
    catch (e) {
      console.log("error", e);
    }
  }

  GetVariantMaster() {
    try {
      this.spinner.show()
      // this.splitvcode = this.Vcode.toString().split('-')
      // this.Vcodedis = this.splitvcode[0]
      this.FDateString = this.fdate.value!.format('YYYYMM');
      this.TDateString = this.fdate.value!.format('YYYYMM');
      console.log('date', this.FDateString + ',' + this.TDateString)
      let option = {
        FDATE: this.FDateString,
        TDATE: this.TDateString
      }
      this.Api_Service.GetVariantMaster(option).subscribe(
        (data: HttpResponse<any>) => {
          if (data.status == 200) {
            console.log('databricks variant data', data)
            this.rslt = data.body  //this.PeriodicElement //data.body
            //this.dataSource = new MatTableDataSource(this.rslt) 
            // console.log('databricks data length', this.rslt.length)
            // debugger;
            if (this.rslt.length > 0) {
              this.drpVariantserver = data.body; //this.rslt.toString()
              console.log('this.drpVariantserver', this.drpVariantserver)
            }
            else {
              swal.fire('No records found', '', 'info')
            }
            this.spinner.hide()
            // console.log('databricks data',  this.rslt)
          }
          else {
            this.spinner.hide()
            swal.fire('Validation Error', '', 'error')
          }
          this.spinner.hide()
        },
        (error) => {
          // console.log('error : ', error)
          this.spinner.hide()
          swal.fire(error.error.message, '', 'error')
        }
      )
      this.drpVariantserversetting = {
        singleSelection: false,
        idField: 'Model',
        textField: 'ModelVariant',
        selectAllText: 'Select All',
        unSelectAllText: 'UnSelect All',
        itemsShowLimit: 1,
        allowSearchFilter: true
      };
    }
    catch (e) {
      console.log("error", e);
    }
  }

  GetParts() {

    // this.spinner.show();
    //this.rpt_service.GetCPKPartMaster(sessionStorage.getItem('VendorID')).subscribe(
    // debugger;
    this.Api_Service.GetCPKPartMasterNew('20135').subscribe(
      data => {
        console.log('PARTS', JSON.parse(data.toString()))

        this.drpserver = JSON.parse(data.toString())

        console.log('PARTS New', this.drpserver)
        // this.spinner.hide();
      }
    );
    this.drpserversetting = {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 1,
      allowSearchFilter: true
    };


  }

  onFilterChange(item: any) {
    console.log(item);
  }
  onDropDownClose(item: any) {
    console.log(item);
  }

  onItemSelect(item: any) {
    console.log(item);
    this.partselected.push(item.item_text);
  }
  onDeSelect(item: any) {
    this.partselected.splice(this.partselected.indexOf(item.item_text), 1);
    console.log('onDeSelect', this.partselected);
  }

  onSelectAll(items: any) {
    let tmp = [];
    for (let i = 0; i < items.length; i++) {
      this.partselected.push(items[i].item_text);
    }
    console.log('onSelectAll', this.partselected);
  }
  onDeSelectAll(items: any) {
    console.log(items);
    this.partselected = items;
  }

  //--new
  onPartSelect(item: any) {
    console.log(item);
    this.materialselected.push(item.PartNo);
  }
  onPartDeSelect(item: any) {
    this.materialselected.splice(this.materialselected.indexOf(item.PartNo), 1);
    console.log('onDeSelect', this.materialselected);
  }

  onPartSelectAll(items: any) {
    let tmp = [];
    for (let i = 0; i < items.length; i++) {
      this.materialselected.push(items[i].PartNo);
    }
    console.log('onSelectAll', this.materialselected);
  }
  onPartDeSelectAll(items: any) {
    console.log(items);
    this.materialselected = items;
  }

  onVariantSelect(item: any) {
    console.log(item);
    this.Variantselected.push(item.item_text);
  }
  onVariantDeSelect(item: any) {
    this.Variantselected.splice(this.Variantselected.indexOf(item.item_text), 1);
    console.log('onDeSelect', this.Variantselected);
  }

  onVariantSelectAll(items: any) {
    let tmp = [];
    for (let i = 0; i < items.length; i++) {
      this.Variantselected.push(items[i].item_text);
    }
    console.log('onSelectAll', this.Variantselected);
  }
  onVariantDeSelectAll(items: any) {
    console.log(items);
    this.Variantselected = items;
  }
  //--


  onItemSelectPlant(item: any) {
    //console.log(item);
  }

  onSelectAllPlant(items: any) {
    //console.log(items);
  }

  onKeydownSalutationPlant(event: any) {
    // if (event.key === "Tab") {           
    //   $('#salutation').find(".dropdown-up").click();            
    //   event.stopPropagation();       
    // }
  }

  removeLastComma(items: string) {
    //console.log(items);
    var strVal = items.trim()
    var lastChar = strVal.slice(-1);
    if (lastChar == ',') {
      strVal = strVal.slice(0, -1);
    }
    return strVal
  }

  ngAfterViewInit() {
    // debugger
    // this.createBarChart();
    // this.getTrendViewData();
    // this.Testingmultichart();
  }

  getChartData() {
    console.log('Selected Time Period Type:', this.selectedTimePeriodType);
    if (this.selectedTimePeriodType === '1') {
      // this.hiddde = true;
      // this.financialToggle = true;
      // this.custom = false;
      this.viewtrendbtn = true;
      this.showTrendView = true;
      this.showBarView = false;
      this.getTrendViewData();
    } else if (this.selectedTimePeriodType === '2') {

      // this.custom = true;
      // this.hiddde = false;
      // this.financialToggle = false;
      this.viewtrendbtn = true;
      this.showTrendView = false;
      this.showBarView = true;
      this.getdata();
    }
  }


  getdata() {
    debugger
    this.FDateString = this.fdate.value!.format('YYYYMM');
    this.TDateString = this.tdate.value!.format('YYYYMM');
    const selectedPlants = this.selectedPlantsList.map(element => `'${element.plantCode}'`).join(', ');
    const PlantData = selectedPlants.split(',').map(str => str.trim());
    // const PlantformattedArray = PlantData.map(str => `'${str}'`);

    this.PlantString = `${selectedPlants}`;
    console.log(this.PlantString, 'ModelVarient');
    const selectedParts = this.selectedPartList.map(element => `'${element.PartNo}'`).join(', ');
    const PartsData = selectedParts.split(',').map(str => str.trim());
    const PartformattedArray = PartsData.map(str => `'${str}'`);
    this.PartString = `${selectedParts}`;

    console.log(this.PartString, 'ModelVarient');

    const selectedModelVarient = this.selectedModelVarientList.map(element => `'${element.ModelVariant}'`).join(', ');
    const ModelVarientsData = selectedModelVarient.split(',').map(str => str.trim());
    const ModelVarientformattedArray = ModelVarientsData.map(str => `'${str}'`);
    this.ModelVarientString = `${selectedModelVarient}`;
    console.log(this.ModelVarientString, 'ModelVarient');

    let option = {
      PartNumber: this.PartString,
      Plant: this.PlantString,
      ModelVarient: this.ModelVarientString,
      FDATE: this.FDateString,
      TDATE: this.TDateString
    }

    this.Api_Service.GetWarrentyBarViewData(option).subscribe(
      // (data) => {
      (data: HttpResponse<any>) => {
        if (data.status == 200) {
          this.rslt1 = data.body;
          console.log('hellodivya', this.rslt1);
          // const filteredArray = this.rslt1.filter((item: { MODEL_VARIANT: any; }) => item.MODEL_VARIANT === 'Sport' );
          this.Model_Varient = this.rslt1.map((item: { MODEL_VARIANT: any; }) => item.MODEL_VARIANT);
          console.log(this.Model_Varient, 'this.Model_Varient')
          const distinctModelVariants = [...new Set(this.Model_Varient)]; // Remove duplicates using a Set
          this.Model_Varient = distinctModelVariants
          console.log(this.Model_Varient, 'distinctModelVariants')

          this.ThreeMonthData = this.rslt1.map((item: { [x: string]: any; }) => item['3_MONTHS_PLANT_PARTS_AGG_DEF']);
          this.SixMonthData = this.rslt1.map((item: { [x: string]: any; }) => item['6_MONTHS_PLANT_PARTS_AGG_DEF']);
          this.TewlveMonthData = this.rslt1.map((item: { [x: string]: any; }) => item['12_MONTHS_PLANT_PARTS_AGG_DEF']);
          console.log(this.ThreeMonthData, 'this.ThreeMonthData')

          this.createBarChart();
        } else {

        }
      }
    )
  }

  createBarChart() {
    debugger;
    this.showTrendView = false;
    this.showBarView = true;
    let array = this.Model_Varient
    console.log(array, 'this.Model')
    const dataSeries = [{
      name: '3 Months',
      data: this.ThreeMonthData,
      color: '#5B9BD5'
    }, {
      name: '6 Months',
      data: this.SixMonthData,
      color: '#ED7D31'
    }, {
      name: '12 Months',
      data: this.TewlveMonthData,
      color: '#A5A5A5'
    }];

    //@ts-ignore
    Highcharts.chart('container', {
      chart: {
        type: 'column'
      },
      credits: {
        enabled: false // Disable Highcharts.com link
      },
      title: {
        text: '',
        enabled: false,
        style: {
          className: 'Trend_chart p-0',
          align: 'left'
        }
      },
      xAxis: {

        categories: array,

        crosshair: true,
        title: {
          text: '<span class="axisformat">Vehicle Models </span>',
          style: {
            className: 'axisformat'
          }
        }
      },
      yAxis: {
        min: 0,
        title: {
          text: '<span class="axisformat">Defects per 100 vehicles </span>',
          style: {
            className: 'axisformat'
          }
        }
      },
      tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
          '<td style="padding:0"><b>{point.y:.1f} mm</b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
      },
      plotOptions: {
        column: {
          pointPadding: 0.1,
          borderWidth: 0,
          point: {
            events: {
              click: (e: { point: any; }) => {
                console.log(e, 'eventvalue')
                const point = e.point;
                const seriesName = point.series.name;
                const seriesData = point.series.data;
                const seriesValue = point.y;
                const category = e.point.category
                console.log(category, category)


                console.log("Series Name:", seriesName);
                console.log("Series Data:", seriesData);
                console.log("Series Value:", seriesValue);

                this.openDialogvehsystem(seriesName, category, seriesValue, this.PartString, this.PlantString, this.ModelVarientString);
              }
            }
          }
        }
      },
      series: dataSeries, // Use the data series defined above
    });

  }


  openDialogvehsystem(seriesName: string, category: string, seriesValue: number, PartString: string, PlantString: string, ModelVarientstring: string) {
    this.FDateString = this.fdate.value!.format('YYYYMM');
    this.TDateString = this.tdate.value!.format('YYYYMM');
    let fdate = this.FDateString;
    let tdate = this.TDateString;
    const dialogRef = this.dialog.open(WarrantymultimodelpopupComponent, {
      width: '1500px',
      height: 'auto',
      maxWidth: '40vw',
      data: { seriesName, category, seriesValue, PartString, PlantString, ModelVarientstring, fdate, tdate }
    });

    dialogRef.afterClosed().subscribe(result => {
      // Perform your action here after the dialog is closed
      console.log('Dialog closed:', result);
    });
  }

  getTrendViewData() {
    debugger
    const selectedPlants = this.selectedPlantsList.map(element => `'${element.plantCode}'`).join(', ');

    console.log("plants=" + selectedPlants);

    const PlantData = selectedPlants.split(',').map(str => str.trim());
    const PlantformattedArray = PlantData.map(str => `'${str}'`);
    const PlantString = PlantformattedArray.join(', ');
    console.log('PlantString', PlantString);

    let option = {

      PartNumber: "1257290",
      Plant: 'HOS',
      fromdate: '202104',
      Todate: '202309'
    }
    this.Api_Service.GetWarrentyTrendViewData(option).subscribe(
      // (data) => {
      (data: HttpResponse<any>) => {
        // debugger
        this.TrendArray = data.body;
        console.log('databricks data', this.TrendArray);
        // const filteredArray = this.TrendArray.filter((item: { MODEL_VARIANT: any; }) => item.MODEL_VARIANT === 'Sport' );
        this.Model_Varient = this.TrendArray.map((item: { MODEL_VARIANT: any; }) => item.MODEL_VARIANT);
        // console.log('Model_Varient', this.Model_Varient)
        debugger
        this.Month = this.TrendArray.map((item: { MONTH: any; }) => item.MONTH);
        console.log('Months', this.Month)

        // Remove duplicates using a Set
        const distinctModelVariants = [...new Set(this.Model_Varient)];
        const distinctMonths = [...new Set(this.Month)];

        this.Model_Varient = distinctModelVariants
        this.Month = distinctMonths

        // const modelVariants = this.TrendArray.map((item: { MODEL_VARIANT: string }) => item.MODEL_VARIANT);
        // this.uniqueModelVariants = [...new Set(modelVariants)];
        // console.log('distinctModelVariants', this.Model_Varient)
        // console.log('distinctMonths', this.Month)

        // Assuming you have an array of objects with a property MODEL_VARIANT
        const uniqueModelVariants = this.TrendArray.map((item: { MODEL_VARIANT: string }) => {
          return { MODEL_VARIANT: item.MODEL_VARIANT };
        });
        // If you want an array of objects with name and value
        this.uniqueModelVariant = uniqueModelVariants.filter(
          (obj: { MODEL_VARIANT: any; }, index: any, self: { MODEL_VARIANT: any; }[]) => index === self.findIndex((item: { MODEL_VARIANT: any; }) => item.MODEL_VARIANT === obj.MODEL_VARIANT)
        );
        // const modelVariants = this.TrendArray.map((item: { MODEL_VARIANT: string }) => item.MODEL_VARIANT);
        //  const uniqueModelVariants = [...new Set(modelVariants)];

        console.log('distinctModelVariants', this.Model_Varient)
        console.log('distinctMonths', this.Month)

        this.OneMonthDefData = this.TrendArray.map((item: { [x: string]: any; }) => item['1_MONTH_PLANT_DEF']);
        this.ThreeMonthDefData = this.TrendArray.map((item: { [x: string]: any; }) => item['3_MONTHS_PLANT_DEF']);
        this.SixMonthDefData = this.TrendArray.map((item: { [x: string]: any; }) => item['6_MONTHS_PLANT_DEF']);
        this.NineMonthDefData = this.TrendArray.map((item: { [x: string]: any; }) => item['9_MONTHS_PLANT_DEF']);
        this.TewlveMonthDefData = this.TrendArray.map((item: { [x: string]: any; }) => item['12_MONTHS_PLANT_DEF']);

        // this.createTrendChart();  //this.createTrendChart
        this.Testingmultichart();

        if (data.status == 200) {

        } else {
        }
      }
    )
  }

  createTrendChart() {
    debugger;
    this.showTrendView = true;
    this.showBarView = false;
    let array = this.Month
    console.log(array, 'this.Model')
    const dataSeries = [{
      name: '1 Months',
      data: this.OneMonthDefData,
      color: '#4472C4'
    }, {
      name: '3 Months',
      data: this.ThreeMonthDefData,
      color: '#ED7D31'
    }, {
      name: '6 Months',
      data: this.SixMonthDefData,
      color: '#A5A5A5'
    }, {
      name: '9 Months',
      data: this.NineMonthDefData,
      color: '#5B9BD5'
    }, {
      name: '12 Months',
      data: this.TewlveMonthDefData,
      color: '#70AD47'
    }];

    //@ts-ignore
    Highcharts.chart('container', {
      chart: {
        type: 'line' // Change chart type to 'line' for multiline chart
      },
      credits: {
        enabled: false // Disable Highcharts.com link
      },
      title: {
        text: '',
        enabled: false,
        style: {
          className: 'Trend_chart p-0',
          align: 'left'
        }
      },
      xAxis: {

        categories: array,

        crosshair: true,
        title: {
          text: '<span class="axisformat">Months</span>',
          style: {
            className: 'axisformat'
          }
        }
      },
      yAxis: {
        min: 0,
        title: {
          text: '<span class="axisformat">Defect per 100</span>',
          style: {
            className: 'axisformat'
          }
        }
      },
      tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
          '<td style="padding:0"><b>{point.y:.1f} mm</b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
      },
      plotOptions: {
        column: {
          pointPadding: 0.1,
          borderWidth: 0,
          point: {
            events: {
              click: (e: { point: any; }) => {
                console.log(e, 'eventvalue')
                const point = e.point;
                const seriesName = point.series.name;
                const seriesData = point.series.data;
                const seriesValue = point.y;
                const category = e.point.category
                console.log(category, category)


                console.log("Series Name:", seriesName);
                console.log("Series Data:", seriesData);
                console.log("Series Value:", seriesValue);

                // this.openDialogvehsystem(seriesName, category, seriesValue);
              }
            }
          }
        }
      },
      series: dataSeries, // Use the data series defined above
    });

  }

  Testingmultichart() {
    /* this.chartDataArray = [
       {
         modelType: 'ModelType1',
         chartOptions: {
           title: { text: 'Line Chart for ModelType1' },
           xAxis: { categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May'] },
           yAxis: { title: { text: 'Value' } },
           series: [
             { name: 'Series 1', type: 'line', data: [5, 10, 15, 7, 20] },
             { name: 'Series 2', type: 'line', data: [8, 12, 18, 10, 30] }
           ]
         }
       },
       {
         modelType: 'ModelType2',
         chartOptions: {
           title: { text: 'Line Chart for ModelType2' },
           xAxis: { categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May'] },
           yAxis: { title: { text: 'Value' } },
           series: [
             { name: 'Series 1', type: 'line', data: [10, 15, 8, 12, 25] },
             { name: 'Series 2', type: 'line', data: [5, 8, 15, 6, 22] }
           ]
         }
       },
       {
         modelType: 'ModelType3',
         chartOptions: {
           title: { text: 'Line Chart for ModelType3' },
           xAxis: { categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May'] },
           yAxis: { title: { text: 'Value' } },
           series: [
             { name: 'Series 1', type: 'line', data: [8, 12, 18, 10, 30] },
             { name: 'Series 2', type: 'line', data: [15, 20, 12, 18, 35] }
           ]
         }
       }
       // Add more ChartData objects for additional model types
     ];
     */
    // debugger
    this.chartDataArray = []
    this.Model_Varient.forEach((modelVariant: string) => {
      // Filter data for the current MODEL_VARIANT
      const filteredData = this.TrendArray.filter((item: { MODEL_VARIANT: string }) => item.MODEL_VARIANT === modelVariant);

      // this.Model_Varient = filteredData.map((item: { MODEL_VARIANT: any; }) => item.MODEL_VARIANT);
      // console.log('Model_Varient', this.Model_Varient)

      this.Month = filteredData.map((item: { MONTH: any; }) => item.MONTH);
      console.log('Months', this.Month)

      // Remove duplicates using a Set
      // const distinctModelVariants = [...new Set(this.Model_Varient)];
      const distinctMonths = [...new Set(this.Month)];

      // this.Model_Varient = distinctModelVariants
      this.Month = distinctMonths

      // Extract data for each period
      this.OneMonthDefData = filteredData.map((item: { [x: string]: any; }) => item['1_MONTH_PLANT_DEF']);
      this.ThreeMonthDefData = filteredData.map((item: { [x: string]: any; }) => item['3_MONTHS_PLANT_DEF']);
      this.SixMonthDefData = filteredData.map((item: { [x: string]: any; }) => item['6_MONTHS_PLANT_DEF']);
      this.NineMonthDefData = filteredData.map((item: { [x: string]: any; }) => item['9_MONTHS_PLANT_DEF']);
      this.TewlveMonthDefData = filteredData.map((item: { [x: string]: any; }) => item['12_MONTHS_PLANT_DEF']);

      this.TrenddataSeries = [{
        name: '1 Months',
        data: this.OneMonthDefData,
        color: '#4472C4'
      }, {
        name: '3 Months',
        data: this.ThreeMonthDefData,
        color: '#ED7D31'
      }, {
        name: '6 Months',
        data: this.SixMonthDefData,
        color: '#A5A5A5'
      }, {
        name: '9 Months',
        data: this.NineMonthDefData,
        color: '#5B9BD5'
      }, {
        name: '12 Months',
        data: this.TewlveMonthDefData,
        color: '#70AD47'
      }];

      this.showTrendView = true;
      this.showBarView = false;
      let CategoryArray = this.Month
      const chartOptions: Highcharts.Options = {
        // title: { text: `Line Chart for ${modelVariant}` },    
        // xAxis: { categories: CategoryArray },
        // yAxis: { title: { text: 'Value' } },
        // series: this.TrenddataSeries,

        title: {
          text: `${modelVariant}`,
          style: {
            className: 'Trend_chart p-0',
            align: 'left',
            fontSize: '14px',
          }
        },
        xAxis: {
          categories: CategoryArray,
          crosshair: true,
          title: {
            text: '<span class="axisformat">Months</span>',
            style: {
              className: 'axisformat'
            }
          }
        },
        yAxis: {
          min: 0,
          title: {
            text: '<span class="axisformat">Defect per 100</span>',
            style: {
              className: 'axisformat'
            }
          }
        },
        tooltip: {
          headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
          pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:.1f} mm</b></td></tr>',
          footerFormat: '</table>',
          shared: true,
          useHTML: true
        },
        plotOptions: {
          column: {
            pointPadding: 0.1,
            borderWidth: 0,
            point: {
              events: {
                click: (e: { point: any; }) => {
                  console.log(e, 'eventvalue')
                  const point = e.point;
                  const seriesName = point.series.name;
                  const seriesData = point.series.data;
                  const seriesValue = point.y;
                  const category = e.point.category
                  console.log(category, category)


                  console.log("Series Name:", seriesName);
                  console.log("Series Data:", seriesData);
                  console.log("Series Value:", seriesValue);

                  // this.openDialogvehsystem(seriesName, category, seriesValue);
                }
              }
            }
          }
        },
        series: this.TrenddataSeries, // Use the data series defined above
        credits: {
          enabled: false
        }
      }
      const newChartData: ChartData = {
        modelType: modelVariant,
        chartOptions: chartOptions
      };

      this.chartDataArray.push(newChartData);
    });
  }
}


