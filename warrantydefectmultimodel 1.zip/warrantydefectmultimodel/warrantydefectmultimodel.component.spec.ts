import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WarrantydefectmultimodelComponent } from './warrantydefectmultimodel.component';

describe('WarrantydefectmultimodelComponent', () => {
  let component: WarrantydefectmultimodelComponent;
  let fixture: ComponentFixture<WarrantydefectmultimodelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WarrantydefectmultimodelComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WarrantydefectmultimodelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
